package com.example.restapi.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;

@Entity
public class Student {
	@Id
	 private Long id;
	    private String StudentNAme;
	    private String FatherName;
		public Student(Long id, String studentNAme, String fatherName) {
			super();
			this.id = id;
			StudentNAme = studentNAme;
			FatherName = fatherName;
		}
		public Student() {
			super();
			// TODO Auto-generated constructor stub
		}
		public Long getId() {
			return id;
		}
		public void setId(Long id) {
			this.id = id;
		}
		public String getStudentNAme() {
			return StudentNAme;
		}
		public void setStudentNAme(String studentNAme) {
			StudentNAme = studentNAme;
		}
		public String getFatherName() {
			return FatherName;
		}
		public void setFatherName(String fatherName) {
			FatherName = fatherName;
		}

}
