package com.example.restapi.service;

import com.example.restapi.dao.studentdao;
import com.example.restapi.entity.Student;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentserviceImpl implements Studentservice {
	@Autowired
	private studentdao studentDao;

	

    @Override
    public List<Student> getStudent() {
    	
    	
        return studentDao.findAll();
    }

    @Override
    public Student addStudent(Student student) {
    
    	studentDao.save(student);
        return student;
    }

    @Override
    public Student updateStudent(Student student) {
       
    	studentDao.save(student);
        return student;
    }

    @Override
    public void deletStudent(long parseLong) {
       
    	Student entity =studentDao.getOne(parseLong);
    	studentDao.delete(entity);
    	
    }
}
