package com.example.restapi.service;

import java.util.List;

import com.example.restapi.entity.Student;

public interface Studentservice {

	public List<Student> getStudent();
	public Student addStudent(Student student);
	public Student updateStudent(Student student);
	public void deletStudent(long parselong);
}
