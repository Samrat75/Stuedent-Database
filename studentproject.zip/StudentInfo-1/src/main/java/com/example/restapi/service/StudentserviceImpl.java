package com.example.restapi.service;

import com.example.restapi.entity.Student;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class StudentserviceImpl implements Studentservice {

    private List<Student> students;

    public StudentserviceImpl() {
        this.students = new ArrayList<>();
    }

    @Override
    public List<Student> getStudent() {
        return this.students;
    }

    @Override
    public Student addStudent(Student student) {
        this.students.add(student);
        return student;
    }

    @Override
    public Student updateStudent(Student student) {
        // Implement update logic here
        return student;
    }

    @Override
    public void deletStudent(long id) {
        // Implement delete logic here
        this.students.removeIf(s -> s.getId() == id);
    }
}
